import pygame, os, sys, random, time
os.chdir("/home/joseph/Documents/CatchTheBomb")

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 800))
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.main_menu_seen = False
        self.white = ((255, 255, 255))
        self.font = pygame.font.SysFont("comicsans", 20)
        self.start_text = self.font.render("Start", 1, self.white)
        self.start_text_rect = pygame.Rect(380, 400, 40, 20)
        self.difficulty = 1
        self.state = "RUNNING"
 
    def main_menu(self):
        while self.main_menu_seen == False:
            mouse = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event == pygame.QUIT:
                    pygame.quit()
                
                if event == pygame.MOUSEBUTTONDOWN and self.start_text_rect.collidepoint(mouse):
                    game.run()
                    self.main_menu_seen = True
                    print("clicked")            
            
            
            self.screen.fill((0, 0, 0))
            pygame.draw.rect(self.screen, self.white, (100, 100, 600, 600), 10)
            self.screen.blit(self.start_text, (self.start_text_rect.x, self.start_text_rect.y))
            pygame.display.update()
            self.clock.tick(self.fps)

    def game_over(self):
        pass

    def run(self):
        last = 0
        key = pygame.key.get_pressed()
        while True:
            print(player.score)
            if player.score < 0:
                self.game_over()
                self.state = "PAUSE"

            if player.score > 10:
                self.difficulty = 2

            x = random.randint(1, 3)
            for event in pygame.event.get():
                if event == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    last = event.key
                
                if event.type == pygame.KEYUP:
                    last = 0

            if last == pygame.K_a or last == pygame.K_LEFT:
                player.move_left()
            
            if last == pygame.K_d or last == pygame.K_RIGHT:
                player.move_right()

            if last == pygame.K_ESCAPE:
                pygame.quit()

            if last == pygame.K_h:
                self.increase_difficulty()

            if last == pygame.K_p:
                self.state = "PAUSE"

            if last == pygame.K_u and self.state == "PAUSE":
                self.state = "RUNNING"

            if last == pygame.K_r:
                self.restart()

            if self.state == "RUNNING" and player.score >= 0:
                self.screen.fill((0, 0, 0))
                self.screen.blit(player.image, (player.rect))
                self.screen.blit(coin.image, (coin.rect))
                self.screen.blit(fire.image, fire.rect)
                if self.difficulty == 2:
                    self.screen.blit(fire_2.image, fire_2.rect)
                    self.screen.blit(fire_3.image, fire_3.rect)
                    self.screen.blit(fire_4.image, fire_4.rect)
                    fire_2.move()
                    fire_3.move()
                    fire_4.move()

                coin.move()
                fire.move()
                player.collision_check()
                player.fire_collision_check()
                score.update_score()
                score.display_score()
                pygame.display.update()
                self.clock.tick(self.fps)

                player.increment_score()
                coin.spawn_new_coin()
                fire.spawn_new_fire()
                if self.difficulty == 2:
                    fire_2.spawn_new_fire()
                    fire_3.spawn_new_fire()
                    fire_4.spawn_new_fire()

            elif self.state == "PAUSE":
                self.screen.fill((255, 255, 255))

    def increase_difficulty(self):
        self.difficulty = 2

    def game_over(self):
        font = pygame.font.Font(None, 36)
        text = font.render('Game Over! Press r to play again', True, self.white)
        text_rect = text.get_rect(center=(400, 350))
        self.screen.fill((0, 0, 0))
        self.screen.blit(text, text_rect)
        pygame.display.flip()

    def restart(self):
        player.rect.x = 350
        player.rect.y = 700
        fire.rect.y = random.randint(-500, -50)
        fire_2.rect.y = random.randint(-500, -50)
        fire_3.rect.y = random.randint(-500, -50)
        fire_4.rect.y = random.randint(-500, -50)
        fire.rect.x = random.randint(0, 800)
        fire_2.rect.x = random.randint(0, 800)
        fire_3.rect.x = random.randint(0, 800)
        fire_4.rect.x = random.randint(0, 800)
        coin.rect.x = random.randint(0, 800)
        coin.rect.y = -50
        self.state = "RUNNING"
        player.score = 0
        self.difficulty = 1
        self.run()

class Player:
    def __init__(self):
        self.x = 400
        self.y = 700
        self.image = pygame.image.load("whiteblock.jpg")
        self.image = pygame.transform.scale(self.image, (100, 10))
        self.rect = self.image.get_rect(topleft = (300, 700))
        self.score = 0
        self.collected = False
        self.invincibilty_timer = 0
        self.list = []
        self.count = 1
        self.font = pygame.font.SysFont("comicsans", 20, True, True)
        self.text = self.font.render(str(self.score), True, (255, 255, 255))
        self.lives = 3
        self.collided = False

    def move_left(self):
        if game.state == "PAUSED":
            self.rect.x -= 0

        if game.difficulty == 1 and game.state != "PAUSED":
            self.rect.x -= 5

        elif game.difficulty == 2 and game.state != "PAUSED":
            self.rect.x -=10

        if self.rect.x < 0:
            self.rect.x = 0

    def move_right(self):
        if game.state == "PAUSED":
            self.rect.x += 0

        if game.difficulty == 1 and game.state != "PAUSED":
            self.rect.x += 5

        elif game.difficulty == 2 and game.state != "PAUSED":
            self.rect.x += 10

        if self.rect.x > 700:
            self.rect.x = 700
            
    def collision_check(self):
        if self.rect.colliderect(coin.rect):
            self.collected = True
            return self.collected

    def fire_collision_check(self):
        if self.rect.colliderect(fire.rect):
            self.collided = True
            self.take_score()
            fire.rect.y = 1000

        if self.rect.colliderect(fire_2.rect):
            self.collided = True
            self.take_score()
            fire_2.rect.y = 1000

        if self.rect.colliderect(fire_3.rect):
            self.collided = True
            self.take_score()
            fire_3.rect.y = 1000    

        if self.rect.colliderect(fire_4.rect):
            self.collided = True
            self.take_score()
            fire_4.rect.y = 1000
                
    def increment_score(self):
        if self.collected == True:
            random_integer = random.randint(1, 5)
            if random_integer < 5:
                self.score += 1
            
            else:
                self.score += 5

            coin.rect.y = 1000
            self.collected = False
            return self.score
            score.update_score()

    def take_score(self):
        if self.collided == True and game.difficulty == 1:
            self.score -= 5
            self.collided = False

        elif self.collided == True and game.difficulty == 2:
            self.score -= 25
            self.collided = False
        
        return self.score
        score.update_score()

class Coin:
    def __init__(self):
        self.x = random.randint(0, 800)
        self.y = -50
        self.image = pygame.image.load("coin.png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect(topleft = (random.randint(0, 750), -50))

    def move(self):
        if game.difficulty == 1:
            self.rect.y += 4

        else:
            self.rect.y += 8
    
    def spawn_new_coin(self):
        if self.rect.y > 801:
            new_x_pos = random.randint(0, 750)
            self.rect.x = new_x_pos
            self.rect.y = -50

class Fire:
    def __init__(self):
        self.image = pygame.image.load("fire.png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect(topleft = (random.randint(0, 800), random.randint(-500, -50)))
    
    def move(self):
        if game.difficulty == 1:
            self.rect.y += 5
        
        else:
            self.rect.y += 8

    def spawn_new_fire(self):
        if self.rect.y > 801:
            new_x_pos = random.randint(0, 800)
            self.rect.x = new_x_pos
            self.rect.y = random.randint(-500, -50)

class Score:
    def __init__(self):
        self.white = ((255, 255, 255))
        self.font = pygame.font.SysFont("comicsans", 20)
        self.text = self.font.render(f"Score: {player.score}", 1, self.white)

    def display_score(self):
        game.screen.blit(self.text, (10, 10))

    def update_score(self):
        self.text = self.font.render(f"Score: {player.score}", 1, self.white)

if __name__ == "__main__":
    game = Game()
    player = Player()
    coin = Coin()
    fire_2 = Fire()
    fire_3 = Fire()
    fire_4 = Fire()
    fire = Fire()
    score = Score()
    game.run()