import pygame, random, sys, os
os.chdir("/home/joseph/Documents/Project Prototypes/Chess")

class Game:
    def __init__(self):
        pygame.init()
        self.width = 800
        self.height = 800
        self.running = True
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.screen = pygame.display.set_mode((self.width, self.height)) #create a display with size 800x, 800y

    def create_board(self):
        board_array = [
            ["BRook", "BKnight", "BBishop", "BQueen", "BKing", "BBishop", "BKinght", "BRook"],
            ["BPawn"] * 8,
            ["-"] * 8,
            ["-"] * 8,
            ["-"] * 8,
            ["-"] * 8,
            ["WPawn"] * 8,
            ["WRook", "WKnight", "WBishop", "WQueen", "WKing", "WBishop", "WKnight", "WRook"],
        ]

        board_colours = [((255, 255, 255)), ((85, 85, 85))]
        for i in range(8):
            for j in range(8):
                square_colour = board_colours[(i +j) % 2]
                pygame.draw.rect(self.screen, square_colour, pygame.Rect(j * 100, i * 100, 100, 100))

    def run(self):
        set_up = False
        while self.running == True:
            for event in pygame.event.get():
                if event == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    column = pos[0] // 100
                    row = pos[1] // 100
                    print(pos)
                    
            if set_up == False:
                self.create_board() #draw the board
                self.set_up_pawns() #blit the pawns to the screen
                self.set_up_rooks() #blit the rooks to the screen
                self.set_up_knights() #blit the knights to the screen
                self.set_up_bishops() #blit the bishops to the screen
                self.set_up_queens() #blit the queens to the screen
                self.set_up_kings() #blit the kings to the screen
            set_up = True
            pygame.display.update() #update the display
            self.clock.tick(self.fps)

    def set_up_pawns(self):
        white_pawn = pygame.image.load("Chess_plt60.png")
        white_pawn = pygame.transform.scale(white_pawn, (80, 80))
        black_pawn = pygame.image.load("Chess_pdt60.png")
        black_pawn = pygame.transform.scale(black_pawn, (80, 80))
        x = 10
        for i in range(8):
            self.screen.blit(white_pawn, (x, 610))
            self.screen.blit(black_pawn, (x, 110))
            x += 100

    def set_up_rooks(self):
        white_rook = pygame.image.load("Chess_rlt60.png")
        white_rook = pygame.transform.scale(white_rook, (80, 80))
        black_rook = pygame.image.load("Chess_rdt60.png")
        black_rook = pygame.transform.scale(black_rook, (80, 80))
        x = 10
        for i in range(2):
            self.screen.blit(white_rook, (x, 710))
            self.screen.blit(black_rook, (x, 10))
            x += 700
            
    def set_up_knights(self):
        white_knight = pygame.image.load("Chess_nlt60.png")
        white_knight = pygame.transform.scale(white_knight, (80, 80))
        black_knight = pygame.image.load("Chess_ndt60.png")
        black_knight = pygame.transform.scale(black_knight, (80, 80))
        x = 110
        for i in range(2):
            self.screen.blit(white_knight, (x, 710))
            self.screen.blit(black_knight, (x, 10))
            x += 500

    def set_up_bishops(self):
        white_bishop = pygame.image.load("Chess_blt60.png")
        white_bishop = pygame.transform.scale(white_bishop, (80, 80))
        black_bishop = pygame.image.load("Chess_bdt60.png")
        black_bishop = pygame.transform.scale(black_bishop, (80, 80))
        x = 210
        for i in range(2):
            self.screen.blit(white_bishop, (x, 710))
            self.screen.blit(black_bishop, (x, 10))
            x += 300

    def set_up_queens(self):
        white_queen = pygame.image.load("Chess_qlt60.png")
        white_queen = pygame.transform.scale(white_queen, (80, 80))
        black_queen = pygame.image.load("Chess_qdt60.png")
        black_queen = pygame.transform.scale(black_queen, (80, 80))
        
        self.screen.blit(white_queen, (310, 710))
        self.screen.blit(black_queen, (310, 10))

    def set_up_kings(self):
        white_king = pygame.image.load("Chess_klt60.png")
        white_king = pygame.transform.scale(white_king, (80, 80))
        black_king = pygame.image.load("Chess_kdt60.png")
        black_king = pygame.transform.scale(black_king, (80, 80))

        self.screen.blit(white_king, (410, 710))
        self.screen.blit(black_king, (410, 10))

class Engine:
    def __init__(self):
        pass

    def get_piece_positions(self):
        pass

if __name__ == "__main__":
    game = Game()
    game.run()