import time

# O(1) - Constant Time
def constant_time(n):
    print("O(1) operation - Constant time")
    return n * 2  # Single operation regardless of input size

# O(n) - Linear Time
def linear_time(n):
    print("O(n) operation - Linear time")
    for i in range(n):
        pass  # Just iterating over n elements

# O(n^2) - Quadratic Time
def quadratic_time(n):
    print("O(n^2) operation - Quadratic time")
    for i in range(n):
        for j in range(n):
            pass  # Nested loop causes quadratic growth

# O(n^k) - Polynomial Time (example: O(n^3))
def polynomial_time(n):
    print("O(n^k) operation - Polynomial time (O(n^3))")
    for i in range(n):
        for j in range(n):
            for k in range(n):
                pass  # Three nested loops for cubic growth

# O(log n) - Logarithmic Time
def logarithmic_time(n):
    print("O(log n) operation - Logarithmic time")
    i = 1
    while i < n:
        i *= 2  # Each step reduces the problem size by half

# Function to measure the time taken by each complexity
def measure_time(func, n):
    start_time = time.time()
    func(n)
    end_time = time.time()
    print(f"Time taken: {end_time - start_time} seconds\n")

# Main execution
n = int(input("Enter the size of n: "))

# Measure time for each complexity in the specified order
measure_time(constant_time, n)      # O(1)
measure_time(linear_time, n)        # O(n)
measure_time(quadratic_time, n)     # O(n^2)
measure_time(polynomial_time, n)    # O(n^k)
measure_time(logarithmic_time, n)   # O(log n)
