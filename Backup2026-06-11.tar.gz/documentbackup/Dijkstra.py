import math #imported math module to use 'math.inf' method

graph = { #set up a graph dictionary with nodes and weights
    'A': {'B': 1, 'C': 4}, 
    'B': {'A': 1, 'C': 2, 'D': 5}, 
    'C': {'A': 4, 'B': 2, 'D': 1}, 
    'D': {'B': 5, 'C': 1} 
} 

def dijkstra(graph, start): #declare function 'dijkstra'
    distances = {node: math.inf for node in graph} #set all distances to positive infinity using 'math.inf' method
    distances[start] = 0 #set the initial distance from the starting node to 0
    previous_nodes = {node: None for node in graph}
    unvisited = set(graph.keys())

    while unvisited:
        current_node = min(unvisited, key = lambda node: distances[node])

        if distances[current_node] == math.inf:
            break

        for neighbour, weight in graph[current_node].items():
            new_distance = distances[current_node] + weight
            if new_distance < distances[neighbour]:
                distances[neighbour] = new_distance
                previous_nodes[neighbour] = current_node

        unvisited.remove(current_node)

    return distances 

print(dijkstra(graph, 'C'))