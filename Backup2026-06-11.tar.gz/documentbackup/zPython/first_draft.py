from simple_term_menu import TerminalMenu
import sys, time, os

class VendingMachine:
    def __init__(self):
        self.__amount_due = 0.00 #amount that needs to be paid
        self.__card_amount = 100.00 #amount of money in the account
        self.payment_processed = False #Boolean so the next transaction be processed
        self.order = [] #empty list to append all items that are ordered to 
        self.stock_list = {
            "Americano": "1.50", 
            "Latte": "1.75", 
            "Hot Chocolate": "1.60", 
            "Iced Coffee": "1.40", 
            "Green Tea": "1.20" 
        } 

    def main_menu(self):
        if self.payment_processed == True:
            options = ["Show Menu", "Exit"] #options for the menu
        
        else:
            options = ["Show Menu", "Order Drinks", "Complete Payment", "Exit"] #options for the menu
        
        terminal_menu = TerminalMenu(options) #create the root menu
        menu_entry_index = terminal_menu.show()

        if options[menu_entry_index] == "Show Menu":
            self.show_menu() #call the show_menu() method

        if options[menu_entry_index] == "Order Drinks":
            self.order_drinks() #call the order_drinks() method

        if options[menu_entry_index] == "Complete Payment":
            self.payment_method() #call the complete_payment() method

        if options[menu_entry_index] == "Exit":
            self.exit() #call the exit() method

    def show_menu(self):
        for key, value in self.stock_list.items(): #loop through the dictionary
            print(f"{key}: £{value}") #print each value
        time.sleep(5)

        os.system("clear") #clear the screen
        self.main_menu() #show the root menu
 
    def order_drinks(self):
        drink_options = ["Americano", "Latte", "Hot Chocolate", "Iced Coffee", "Green Tea", "Return To Root Menu"] #options for the drink menu
        drink_menu = TerminalMenu(drink_options) #create the menu
        drink_selection = drink_menu.show()

        if drink_options[drink_selection] == "Americano":
            self.order.append("Americano") #append to the empty list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Latte":
            self.order.append("Latte") #append to the list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Hot Chocolate":
            self.order.append("Hot Chocolate") #append to the list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Iced Coffee":
            self.order.append("Iced Coffee") #append to the list 
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Green Tea":
            self.order.append("Green Tea") #append to the list 
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Return To Root Menu":
            os.system("clear") #clear the screen
            self.main_menu() #show the root menu

    def card_payment(self):
        for i in self.order:
            if i == "Americano":
                self.__amount_due += 1.50 #adds 1.50 to the self.amount_due variable
            
            elif i == "Latte":
                self.__amount_due += 1.75 #adds 1.75 to the self.amount_due variable

            elif i == "Hot Chocolate":
                self.__amount_due += 1.60 #adds 1.60 to the self.amount_due variable
            
            elif i == "Iced Coffee":
                self.__amount_due += 1.40 #adds 1.40 to the self.amount_due variable

            elif i == "Green tea":
                self.__amount_due += 1.20 #adds 1.20 to the self.amount_due variable
        
        print(f"Amount Due: £{str(self.__amount_due)}") #print the self.amount_due attribute
        self.__card_amount -= self.__amount_due #minus the self.amount_due variable from the self.__card_amount variable
        self.payment_processed = True #set the boolean value to true
        print(self.__amount_due)
        print("Payment Successfully Processed.") #print a confirmation
        print(f"Current Balance: £{str(self.__card_amount)}") #show the current balance
        time.sleep(5) #wait for five seconds
        os.system("clear") #clear the screen
        self.main_menu() #show the root menu

    def cash_payment(self):
        for i in self.order:
            if i == "Americano":
                self.__amount_due += 1.50 #adds 1.50 to the self.amount_due variable
            
            elif i == "Latte":
                self.__amount_due += 1.75 #adds 1.75 to the self.amount_due variable

            elif i == "Hot Chocolate":
                self.__amount_due += 1.60 #adds 1.60 to the self.amount_due variable
            
            elif i == "Iced Coffee":
                self.__amount_due += 1.40 #adds 1.40 to the self.amount_due variable

            elif i == "Green tea":
                self.__amount_due += 1.20 #adds 1.20 to the self.amount_due variable
        
        print(f"Amount Due: £{str(self.__amount_due)}") #print the self.amount_due attribute
        print("---INSERT PAYMENT---")
        self.__card_amount -= self.__amount_due #minus the self.amount_due variable from the self.__card_amount variable
        self.payment_processed = True #set the boolean value to true
        print("Payment Successfully Processed.") #print a confirmation
        time.sleep(5) #wait for five seconds
        os.system("clear") #clear the screen
        self.main_menu() #show the root menu

    def payment_method(self):
        os.system("clear")
        methods = ["Cash", "Bank Card"] #options for the menu
        terminal_menu = TerminalMenu(methods) #create the root menu
        method = terminal_menu.show()

        if methods[method] == "Cash":
            self.cash_payment()
        
        else:
            self.card_payment()


    def exit(self):
        os.system("clear") #clear the screen
        sys.exit() #stop the program

vendingmachine = VendingMachine() #class object
vendingmachine.main_menu() #call the main_menu method of class VendingMachine



