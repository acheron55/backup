from simple_term_menu import TerminalMenu
import sys, time, os

class CafeTill:
    def __init__(self):
        self.order = []
        self.payment_processed = False
        self.__card_amount = 100.00
        self.__amount_due = 0
        self.price_multiplier = 1
        self.discount_applied = False

    def order_drinks(self):
        drink_options = ["Tea", "Coffee", "Hot Chocolate", "Coke", "Iced Coffee", "Return To Root Menu"] #options for the drink menu
        drink_menu = TerminalMenu(drink_options) #create the menu
        drink_selection = drink_menu.show()

        if drink_options[drink_selection] == "Tea":
            self.order.append("Tea") #append to the empty list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Coffee":
            self.order.append("Coffee") #append to the list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Hot Chocolate":
            self.order.append("Hot Chocolate") #append to the list
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Coke":
            self.order.append("Coke") #append to the list 
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Iced Coffee":
            self.order.append("Iced Coffee") #append to the list 
            print(f"Added {drink_options[drink_selection]} to order.") #print a confirmation
            os.system("clear") #clear the screen
            self.order_drinks() #show the drinks menu

        if drink_options[drink_selection] == "Return To Root Menu":
            os.system("clear") #clear the screen
            self.main_menu() #show the root menu

    def main_menu(self):
        if self.payment_processed == True:
            options = ["Show Menu", "Exit"] #options for the menu
        
        else:
            options = ["Order Drinks", "Complete Payment", "Apply Discount", "Exit"] #options for the menu
        
        terminal_menu = TerminalMenu(options) #create the root menu
        menu_entry_index = terminal_menu.show()

        if options[menu_entry_index] == "Order Drinks":
            self.order_drinks() #call the order_drinks() method

        if options[menu_entry_index] == "Complete Payment":
            self.payment_method() #call the complete_payment() method

        if options[menu_entry_index] == "Apply Discount":
            self.apply_discount()

        if options[menu_entry_index] == "Exit":
            os.system("clear")
            sys.exit()

    def card_payment(self):
        for i in self.order:
            if i == "Tea":
                self.__amount_due += (1.50 * self.price_multiplier) #adds 1.50 to the self.amount_due variable
            
            elif i == "Coffee":
                self.__amount_due += (1.75 * self.price_multiplier) #adds 1.75 to the self.amount_due variable

            elif i == "Hot Chocolate":
                self.__amount_due += (1.60 * self.price_multiplier) #adds 1.60 to the self.amount_due variable
            
            elif i == "Coke":
                self.__amount_due += (1.40 * self.price_multiplier) #adds 1.40 to the self.amount_due variable

            elif i == "Iced Coffee":
                self.__amount_due += (1.20 * self.price_multiplier) #adds 1.20 to the self.amount_due variable
        
        print(f"Amount Due: £{str(self.__amount_due)}") #print the self.amount_due attribute
        self.__card_amount -= self.__amount_due #minus the self.amount_due variable from the self.__card_amount variable
        self.payment_processed = True #set the boolean value to true
        print(self.__amount_due)
        print("Payment Successfully Processed.") #print a confirmation
        print(f"Current Balance: £{str(self.__card_amount)}") #show the current balance
        time.sleep(5) #wait for five seconds
        os.system("clear") #clear the screen
        self.main_menu() #show the root menu

    def cash_payment(self):
        for i in self.order:
            if i == "Tea":
                self.__amount_due += (1.50 * self.price_multiplier) #adds 1.50 to the self.amount_due variable
            
            elif i == "Coffee":
                self.__amount_due += (1.75 * self.price_multiplier) #adds 1.75 to the self.amount_due variable

            elif i == "Hot Chocolate":
                self.__amount_due += (1.60 * self.price_multiplier) #adds 1.60 to the self.amount_due variable
            
            elif i == "Coke":
                self.__amount_due += (1.40 * self.price_multiplier) #adds 1.40 to the self.amount_due variable

            elif i == "Iced Coffee":
                self.__amount_due += (1.20 * self.price_multiplier) #adds 1.20 to the self.amount_due variable
        
        print(f"Amount Due: £{str(self.__amount_due)}") #print the self.amount_due attribute
        print("---INSERT PAYMENT---")
        self.__card_amount -= self.__amount_due #minus the self.amount_due variable from the self.__card_amount variable
        self.payment_processed = True #set the boolean value to true
        print("Payment Successfully Processed.") #print a confirmation
        time.sleep(5) #wait for five seconds
        os.system("clear") #clear the screen
        self.main_menu() #show the root menu

    def payment_method(self):
        os.system("clear")
        methods = ["Cash", "Bank Card"] #options for the menu
        terminal_menu = TerminalMenu(methods) #create the root menu
        method = terminal_menu.show()

        if methods[method] == "Cash":
            self.cash_payment()
        
        else:
            self.card_payment()

    def apply_discount(self):
        while True:
            try:
                student_code = int(input("Enter Your Student Code: "))
                if (student_code % 10) != 5:
                    print("Invalid Student Code.")
                    time.sleep(2)
                    os.system("clear")
                    self.main_menu()
                    break

                elif (student_code % 10) == 5 and self.discount_applied == False:
                    self.price_multiplier = 0.9
                    self.discount_applied = True
                    print("Student Code Accepted.")
                    time.sleep(2)
                    os.system("clear")
                    self.main_menu()
                    break

                elif self.discount_applied == True:
                    print("You cannot apply multiple discounts. ")
                    time.sleep(2)
                    os.system("clear")
                    
                    self.main_menu()
                    break

            except ValueError:
                print("Invalid Input. Please input numbers only.")

till = CafeTill()
till.main_menu()