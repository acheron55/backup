def Sum():
    number_list = []
    sum_of_numbers = 0
    for i in range(10):
        number = float(input("Enter a number: "))
        number_list.append(number)
    for j in number_list:
        sum_of_numbers += number_list[j]
        print(sum_of_numbers)


def factorial_calculate():
    number = 5
    if number > 0:
        n = number - 1
        while n > 0:
            number *= n
            n -= 1
        print(number)   

factorial_calculate()