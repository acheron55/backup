class Item:
    def __init__(self , name , price , weight , volume , temp):
        self.name = name
        self.price = price
        self.weight = weight
        self.volume = volume
        self.temp = temp
 
    def menu(self):
        print ("Menu:")
        print ("1: " + drink1.name)
        print ("2: " + drink2.name) 
        print ("3: " + drink3.name)

    def order(self):
        global totalp
        global totalw
        global totalv
        totalp = 0 
        totalw = 0
        totalv = 0
        true = "true"
        while true == "true":
            choice = input("enter the number corilating to the menu item you would like or enter done if you dont want anything else")
            if choice == "1":
                print("adding coffee")
                totalp = totalp + drink1.price
                totalw = totalw + drink1.weight
                totalv = totalv + drink1.volume
            elif choice == "2":
                print("adding tea")
                totalp = totalp + drink2.price
                totalw = totalw + drink2.weight
                totalv = totalv + drink2.volume
            elif choice == "3":
                print ("adding hot chocolate")
                totalp = totalp + drink3.price
                totalw = totalw + drink3.weight
                totalv = totalv + drink3.volume
            elif choice.lower() == ("done"):
                true = "false"
            else:
                print ("invalid input try again")
 
    def payment(self):
        paymenttype = input("cash or card")
        if paymenttype.lower() == ("cash"):
            print ("please enter £" + str(totalp))
            money = float(input("how much money did you enter"))
            if money < float(totalp):
                addmoney = totalp - money
                print("please add £" + str(addmoney))
                money2 = input("how much did u enter")
                if float(money2) < float(addmoney):
                    print("payment failed")
 
                else:
                    print("thank you , you may take your items")
 
            else:
                print("thank you , you may take your items")
 
        elif paymenttype.lower() == "card":
            print ("thank you , you may take your items")
 
drink1 = Item("coffee" , 2.00 , 300 , 500 , 94)
drink2 = Item("tea" , 3.00 , 300 , 500 , 94)
drink3 = Item("hot chocolate" , 1.00 , 300 , 500 , 94)

item = Item() 
item.menu()
item.order()
item.payment()
