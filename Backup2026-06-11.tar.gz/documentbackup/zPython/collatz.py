class Calculation:
    def __init__(self):
        self.reached_one = False

    def Collatz(self):
        while True:
            try:
                number = int(input("Enter a positive integer: "))
                break
            
            except ValueError:
                print("Please Enter an integer")

        while True:
            if number % 2 == 0:
                number //= 2
            
            else:
                number *= 3
                number += 1

            print(number)

            if number == 1:
                break

calc = Calculation()
calc.Collatz()
