import pygame, time, sys, random

class Player:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 800))
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.white = ((255, 255, 255))
        self.difficulty = 1
        self.state = "RUNNING"
        self.ships_amount = 5

    def place_ship(self):
        pass

class Ship:
    def __init__(self):
        self.length = 2
        