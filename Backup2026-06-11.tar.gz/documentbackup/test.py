studentscores = [9,8,7,6,5,4,3,2,1]
length = len(studentscores)
temp = 0  
swapped = 0
true = 1
while true == 1  :    
    print(studentscores)    
    for i in range (length-2):
            if studentscores[i]>studentscores[i+1]:
                swapped = swapped + 1 
                temp = studentscores[i]
                studentscores[i] = studentscores[i+1]
                studentscores[i] = temp 