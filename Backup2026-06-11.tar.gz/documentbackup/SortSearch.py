list = [2, 6, 1, 2, 8, 11, 1, 3, -99, 9, 13, 19, 25, 23, 67, 101, 88, 23, 909]
arr = list

list_length = len(list)

def linear_search():
    found = False
    while found != True:
        try:
            search_term = int(input("Enter a search term: "))
            for i in list:
                if i == search_term:
                    found = True

                else:
                    pass

        except ValueError:
            print("Please input an integer (whole number) as the search term.")

    if found == True:
        print("Found!")

def binary_search():
    search_term = int(input("Enter a search term: "))
    found = False
    lowerBound = 0
    upperBound = list_length

    while found != True:
        try:
            midpoint = (lowerBound + upperBound) // 2
            if list[midpoint] == search_term:
                found = True
            
            elif list[midpoint] > search_term:
                upperBound = midpoint - 1
            
            else:
                lowerBound = midpoint + 1

        except ValueError:
            print("Please input an integer (whole number) as the search term.")

    print(f"Found {search_term} at position {midpoint}")

def bubble_sort():
    counter = 0
    swapped = True
    swaps = 0

    while swapped == True:
        while counter < (list_length - 1):
            if list[counter] > list[counter + 1]:
                temp = list[counter]
                list[counter] = list[counter + 1]
                list[counter + 1] = temp

                swaps += 1

            print(f"Pass {counter + 1}: {list}")
            counter += 1
        
        if swaps == 0:
            swapped = False

        else:
            swaps = 0
            counter = 0


def insertion_sort():
    for i in range(1, (list_length -1)):
        current = list[i]
        previous = i

        while previous > 0 and list[previous - 1] > current:
            list[previous] = list[previous - 1]
            previous -= 1
            list[previous] = current
    
    print(list)

def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = arr[:mid]
    right = arr[mid:]
    
    left = merge_sort(left)
    right = merge_sort(right)
    
    return merge(left, right)

def merge(left, right):
    result = []
    left_idx, right_idx = 0, 0
    
    while left_idx < len(left) and right_idx < len(right):
        if left[left_idx] <= right[right_idx]:
            result.append(left[left_idx])
            left_idx += 1
        else:
            result.append(right[right_idx])
            right_idx += 1
    
    result.extend(left[left_idx:])
    result.extend(right[right_idx:])
    return result

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if arr[j] < pivot:
            i += 1
            swap(arr, i, j)

    swap(arr, i + 1, high)
    return (i + 1)

def swap(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]

def quick_sort(arr, low, high):
    if low < high:
        pivotIndex = partition(arr, low, high)
        quick_sort(arr, low, pivotIndex - 1)
        quick_sort(arr, pivotIndex + 1, high)

print(quick_sort(arr, 0, list_length - 1))