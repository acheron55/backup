import pygame, sys

class Game:
    def __init__(self):
        pygame.init()
        self.width = 1000
        self.height = 1000
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()
        self.fps = 60
        self.state = "RUNNING"

    def run(self):
        last = 0
        key = pygame.key.get_pressed()

        while True:
            for event in pygame.event.get():
                if event == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    last = event.key
                
                if event.type == pygame.KEYUP:
                    last = 0

            if last == pygame.K_a or last == pygame.K_LEFT:
                player.move_left()
            
            if last == pygame.K_d or last == pygame.K_RIGHT:
                player.move_right()

            if last == pygame.K_ESCAPE:
                pygame.quit()

            if self.state == "RUNNING":
                self.screen.fill((255, 255, 255))

class Player:
    def __init__(self):
        self.velocity = 5
        

    def jump(self):
        self.rect.y -= 10
        

if __name__ == "__main__":
    game = Game()
    game.run()